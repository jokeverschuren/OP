var main = function () {
  "use strict";

  setInterval(function() {


  		$(".kader1").fadeIn(1000, function() {
  			$(".kader1").removeClass("hidden");
  			$(".kader2").fadeIn(3000, function() {
  				$(".kader2").removeClass("hidden");
  				$(".kader3").fadeIn(3000, function() {
  					$(".kader3").removeClass("hidden");
  					$(".kader4").fadeIn(3000, function() {
  						$(".kader4").removeClass("hidden");
  						$(".kader5").fadeIn(3000, function() {
				  			$(".kader5").removeClass("hidden");
				  			$(".kader6").fadeIn(3000, function() {
					  			$(".kader6").removeClass("hidden");
					  			$(".kader7").fadeIn(3000, function() {
						  			$(".kader7").removeClass("hidden");
						  			$(".kader8").fadeIn(3000, function() {
							  			$(".kader8").removeClass("hidden");
							  		});
						  		});
					  		});
				  		});
  					});
  				});
  			});
  		});
  	});
}
  
$("document").ready(main);

