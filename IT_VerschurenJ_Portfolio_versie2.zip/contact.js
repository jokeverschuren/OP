var main = function () {
  "use strict";

  $(".send").on("click", function () {
  	$(".geraamte").addClass("hidden");
  	$(".danku").removeClass("hidden");
  });

 };
 $("document").ready(main);